/* eslint no-var: 0 */
var main = require('./dist/cjs/i18next.js');

module.exports = main;
module.exports.default = main;
