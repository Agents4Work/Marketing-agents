const ns2 = {
  description: {
    part1:
      'In order to infer the appropriate type for t function, you should use type augmentation to override the Resources type.',
    part2: 'Check out the @types/i18next to see an example.',
  },
} as const;

export default ns2;
